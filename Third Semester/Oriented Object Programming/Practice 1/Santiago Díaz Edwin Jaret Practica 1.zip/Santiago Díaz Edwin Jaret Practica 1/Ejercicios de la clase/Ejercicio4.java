public class Ejercicio4 {
    public static void main(String[] args) {
        System.out.println(Calculadora.Sumar());
        System.out.println(Calculadora.Restar());
        System.out.println(Calculadora.Multiplicar());
        System.out.println(Calculadora.Modulo());
    }
}
