public class Ejercicio1{

	static int a;
	static int b;

	public static void metodo1(){
		System.out.println("Práctica 1 y ya reprobé");
	}

	public static void main(String[] Juan) {
		System.out.println("Bienvenido al laboratorio");
        a=10;
		b=100;
		System.out.println("resultado suma random: "+a+b);
		metodo1();
	}

}