public class Clase3 {
	
	public static void metodo8(){
		int a = 10;
		System.out.println("¿Cuál es la diferencia entre return y print?");
		System.out.println("Aquí adentro a vale "+a+" XD");
	}
}