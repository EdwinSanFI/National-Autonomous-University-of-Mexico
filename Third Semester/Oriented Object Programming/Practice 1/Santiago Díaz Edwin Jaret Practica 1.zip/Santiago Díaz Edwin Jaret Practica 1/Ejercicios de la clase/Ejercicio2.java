public class Ejercicio2{

	public static void main(String[] args) {
		
	
		//Uso de Println
		int num_semestre= 3;
		String plan ="computacion";
		System.out.println("Asignaturas del " + num_semestre + "er semestre de "+plan);
		System.out.println("  * Programacion Orientada a objetos");
		System.out.println("  * Estructura de datos y algoritmos 2");
		System.out.println("  * Las");
		System.out.println("  * otras ");
		System.out.println("  * no");
		System.out.println("  * cuentan");
		System.out.println("  * bueno si");
		
		//Uso de print
		// System.out.print("Aqui  ");
		// System.out.print("estoy  ");
		// System.out.println("Imprimiendo ");
		// System.out.print("H");
		// System.out.print("o");
		// System.out.print("l");
		// System.out.print("a");

		//Uso de printf
		int a=10;
		String texto1= "prueba";
		String texto2= "Aprende Java";
		String texto3= "En 21 dias";
		System.out.printf("Un entero: %d \n",a);
		System.out.printf("Una cadena: %s \n",texto1);
		System.out.printf("Dos cadenas: %s  %s",texto2,texto3);

	}


}