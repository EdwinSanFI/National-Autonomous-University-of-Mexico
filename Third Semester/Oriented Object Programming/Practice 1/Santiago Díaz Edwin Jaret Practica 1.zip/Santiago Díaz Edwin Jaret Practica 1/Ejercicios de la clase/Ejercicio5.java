public class Ejercicio5 {
    public static void main(String[] args) {
        System.out.println("Hola Mundo");
        Int a = 23;
        float 23 = 3.14;
        double Alumn@ = 9.811956;
        char _Var = "Hola";
        int null = 24;
        int Null = 10.6;
        string cadena = "hola";
    }
}