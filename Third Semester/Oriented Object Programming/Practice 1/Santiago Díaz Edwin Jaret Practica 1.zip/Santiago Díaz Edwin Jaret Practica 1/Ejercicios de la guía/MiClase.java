public class MiClase {
    public static void main(String[] args) {
        System.out.println("Esta es mi clase");
    }
}