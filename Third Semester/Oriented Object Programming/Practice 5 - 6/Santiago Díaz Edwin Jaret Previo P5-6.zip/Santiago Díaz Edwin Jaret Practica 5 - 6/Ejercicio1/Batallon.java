package Ejercicio1;

public class Batallon {
    static int numeroBatallones;

    /**
     * Metodo constructor , deben de ser 2
     */

    public void MostrarInformacion(){}

}
