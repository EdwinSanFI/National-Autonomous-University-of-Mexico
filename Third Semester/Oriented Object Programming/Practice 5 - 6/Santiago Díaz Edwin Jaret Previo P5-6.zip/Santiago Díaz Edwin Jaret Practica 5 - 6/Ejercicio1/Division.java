package Ejercicio1;
public class Division {

    /**
     * Metodo constructor , deben de ser 2
     */

    public void asignarDivisionABatallon(){}
     
    public void MostrarInformacion(){}
}
