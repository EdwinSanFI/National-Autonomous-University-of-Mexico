package Ejercicio1;

public class Principal {
    public static void main(String[] args) {
        System.out.println("\t**Practica 5-6**");
    }
}
