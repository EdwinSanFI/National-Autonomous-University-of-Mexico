package Ejercicio1;

public class Militar {
    static int numeroMilitares, edad;
    String nombreMilitar, Apellido;

    public Militar(){
    }
    public Militar(){

    }

    public void asignarMilitarADivision(){}

    public void MostrarInformacion(){}

}
