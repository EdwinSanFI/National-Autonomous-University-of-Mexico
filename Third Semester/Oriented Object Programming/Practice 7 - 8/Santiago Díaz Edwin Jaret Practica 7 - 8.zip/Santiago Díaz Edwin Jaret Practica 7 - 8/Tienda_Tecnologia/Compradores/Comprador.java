package Tienda_Tecnologia.Compradores;

public abstract class Comprador {
    abstract void imprimirLista();
    abstract void procesoCompra();
}
